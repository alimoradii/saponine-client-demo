#!/usr/bin/env python3
"""Build and verify the WordPress delivery, including both installable ZIPs."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
output = root.parent / 'deliverables'
output.mkdir(exist_ok=True)
packages = ('saponine-flex', 'saponine-studio')


def files(folder):
    return sorted(path for path in folder.rglob('*')
                  if path.is_file() and '__pycache__' not in path.parts)


for package in packages:
    installable = output / (package + '.zip')
    with zipfile.ZipFile(installable, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files(root / package):
            archive.write(path, path.relative_to(root).as_posix())
    with zipfile.ZipFile(installable) as archive:
        assert archive.testzip() is None
        entry = 'style.css' if package == 'saponine-flex' else 'saponine-studio.php'
        assert package + '/' + entry in archive.namelist()

ignored = {'SHA256SUMS.json', *(name + '.zip' for name in packages)}
entries = {p.relative_to(root).as_posix(): p for p in files(root)
           if p.relative_to(root).as_posix() not in ignored}
entries.update({name + '.zip': output / (name + '.zip') for name in packages})
manifest = [{'path': name, 'bytes': path.stat().st_size,
             'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in sorted(entries.items())]
checksum = root / 'SHA256SUMS.json'
checksum.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
entries[checksum.name] = checksum
target = output / 'Saponine-WordPress-Editable.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(entries.items()):
        archive.write(path, name)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(set(archive.namelist())) == len(archive.namelist())
    assert all(hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
               for row in manifest)
print(target)
