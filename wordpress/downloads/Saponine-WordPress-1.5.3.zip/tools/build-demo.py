#!/usr/bin/env python3
"""Build editable Elementor JSON from readable data. No HTML/shortcode page wrappers."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'saponine-studio' / 'demo'
OUT.mkdir(parents=True, exist_ok=True)
counter = 0
def uid(label=''):
    global counter
    counter += 1
    return hashlib.sha1(f'{counter}:{label}'.encode()).hexdigest()[:7]
def size(value, unit='px'): return {'size':value,'unit':unit,'sizes':[]}
def dims(t=0,r=None,b=None,l=None,unit='px'):
    r=t if r is None else r; b=t if b is None else b; l=r if l is None else l
    return {'unit':unit,'top':str(t),'right':str(r),'bottom':str(b),'left':str(l),'isLinked':t==r==b==l}
def media(name): return {'url':'{{asset:'+name+'}}','id':0}
def link(url): return {'url':url,'is_external':'','nofollow':''}
def reveal(delay=0): return {'sn_motion_effect':'reveal','sn_motion_duration':850,'sn_motion_delay':delay,'sn_motion_distance':24,'sn_motion_trigger':'viewport','sn_motion_mobile':'yes'}
def node(kind, settings=None, children=None, name=''):
    result={'id':uid(name or kind),'elType':'container' if kind=='container' else 'widget','settings':settings or {},'elements':children or []}
    if kind!='container': result.update(widgetType=kind)
    if name: result['settings']['_title']=name
    return result
def con(name, children, **settings):
    values={'content_width':'full','flex_direction':'column','flex_gap':{'column':'0','row':'0','isLinked':True,'unit':'px','size':0},'padding':dims(0)}
    values.update(settings)
    return node('container',values,children,name)
def widget(kind,name,**settings):
    # Inherit the theme's editable font defaults; a later Elementor font choice wins.
    family = settings.get('typography_font_family')
    if family in ('Vazirmatn','Outfit'):
        del settings['typography_font_family']
        font_class = 'sn-latin-font' if family == 'Outfit' else 'sn-body-font'
        settings['_css_classes'] = (settings.get('_css_classes','')+' '+font_class).strip()
    return node(kind,settings,[],name)
def heading(text,level='h2',font=40,weight=900,align='start',color=None,name=None,**extra):
    s={'title':text,'header_size':level,'align':align,'typography_typography':'custom','typography_font_family':'Vazirmatn','typography_font_size':size(font),'typography_font_size_mobile':size(min(font,28)),'typography_font_weight':str(weight),'typography_line_height':size(1.5,'em')}
    s['title_color']=color or 'var(--sn-text)'
    s.update(extra)
    return widget('heading',name or text,**s)
def text(content,font=16,align='start',color=None,name=None,**extra):
    s={'editor':'<p>'+content+'</p>','align':align,'typography_typography':'custom','typography_font_family':'Vazirmatn','typography_font_size':size(font),'typography_line_height':size(2.1,'em')}
    s['text_color']=color or 'var(--sn-text)'
    s.update(extra)
    return widget('text-editor',name or content[:35],**s)
def button(label,url,light=False,outline=False,**extra):
    s={'text':label,'link':link(url),'align':'start','typography_typography':'custom','typography_font_family':'Vazirmatn','typography_font_size':size(14),'typography_font_weight':'500','border_radius':dims(12),'text_padding':dims(12,28),'background_color':'#ffffff' if light else ('#00000000' if outline else 'var(--sn-primary)'),'button_text_color':'var(--sn-primary)' if light else ('var(--sn-text)' if outline else '#ffffff'),'hover_color':'#ffffff','button_background_hover_color':'var(--sn-primary)'}
    if outline:s.update(border_border='solid',border_width=dims(1),border_color='var(--sn-border)')
    s.update(extra)
    return widget('button',label,**s)
def image(name,filename,width=100,unit='%',**extra):
    s={'image':media(filename),'image_size':'full','width':size(width,unit),'align':'center'};s.update(extra)
    return widget('image',name,**s)
def section(name,anchor,children,background=None,**extra):
    s={'_element_id':anchor,'html_tag':'section','content_width':'boxed','boxed_width':size(1280),'min_height':size(100,'vh'),'min_height_mobile':size(0),'flex_justify_content':'center','flex_align_items':'stretch','padding':dims(110,24,100),'padding_mobile':dims(80,20,80),'css_classes':'sn-panel'}
    if background:s.update(background_background='classic',background_color=background)
    s.update(extra)
    return con(name,children,**s)
def icon(name,value,**extra):
    s={'selected_icon':{'value':'fas fa-'+value,'library':'fa-solid'},'primary_color':'var(--sn-primary)','size':size(32),'view':'default'};s.update(extra)
    return widget('icon',name,**s)

# Header: each piece is an independent widget or container.
navitems=[('برندهای ساپونین','sec-2'),('محصولات','sec-4'),('درباره ما','sec-3'),('تماس با ما','sec-6')]
headerbar=con('سربرگ شناور — جایگاه و رنگ قابل ویرایش',[
    con('لوگو و فهرست',[
        image('لوگوی سایت','logo.png',174,'px',width_tablet=size(124),width_mobile=size(124),link_to='custom',link=link('{{home}}#sec-0'),_element_width='auto',_padding=dims(0),_css_classes='sn-header-logo-plate sn-header-logo'),
        widget('saponine-navigation','فهرست اصلی',items=[{'_id':uid(), 'label':t,'link':link('{{home}}#'+a)} for t,a in navitems],menu_label='فهرست اصلی',toggle_label='فهرست',breakpoint='tablet'),
    ],flex_direction='row',flex_wrap_mobile='nowrap',flex_align_items='center',flex_justify_content_mobile='space-between',flex_gap={'column':'32','row':'16','unit':'px','isLinked':False},flex_gap_tablet={'column':'20','row':'12','unit':'px','isLinked':False},flex_gap_mobile={'column':'10','row':'10','unit':'px','isLinked':True},width=size(76,'%'),width_tablet=size(62,'%'),width_mobile=size(100,'%'),css_classes='sn-header-main'),
    con('جستجو و داروخانه‌ها',[
        widget('saponine-search','جستجوی وردپرس',toggle_label='جستجو',placeholder='جستجو در سایت…',field_label='عبارت مورد نظر',submit_label='جستجو'),
        button('داروخانه‌ها','{{home}}#sec-5',text_padding=dims(10,28),text_padding_tablet=dims(8,15),text_padding_mobile=dims(8,12),typography_font_size=size(18),typography_font_size_tablet=size(15),typography_font_size_mobile=size(14),typography_font_weight='650',border_radius=dims(15),_element_width='auto'),
        widget('saponine-language-switcher','انتخاب زبان سایت',label_mode='code',orientation='row',show_current='yes',hide_single='yes',switcher_label='انتخاب زبان',_element_width='auto'),
    ],flex_direction='row',flex_wrap='wrap',flex_align_items='center',flex_justify_content='flex-end',flex_gap={'column':'8','row':'8','unit':'px','isLinked':True},width=size(24,'%'),width_tablet=size(38,'%'),width_mobile=size(100,'%'),css_classes='sn-header-actions'),
],flex_direction='row',flex_wrap_mobile='wrap',flex_justify_content='space-between',flex_align_items='center',flex_gap_mobile={'column':'10','row':'8','unit':'px','isLinked':False},width=size(90,'%'),width_tablet=size(95,'%'),width_mobile=size(95,'%'),min_height=size(75),min_height_tablet=size(56),min_height_mobile=size(56),padding=dims(10,13),padding_tablet=dims(6,9),padding_mobile=dims(6,8),border_radius=dims(20),border_radius_tablet=dims(16),border_radius_mobile=dims(16),background_background='classic',background_color='#ffffff',box_shadow_box_shadow_type='yes',box_shadow_box_shadow={'horizontal':0,'vertical':3,'blur':18,'spread':0,'color':'#27222E12'},position='fixed',_offset_orientation_h='start',_offset_x=size(0),_offset_x_tablet=size(0),_offset_x_mobile=size(0),_offset_orientation_v='start',_offset_y=size(29),_offset_y_tablet=size(10),_offset_y_mobile=size(10),z_index=100,css_classes='sn-header-bar')
strip=[]
branddata=[('ساپونین بالانس','Saponine Balance','bottle.jpg'),('سرم بوتانیکال','Botanical Serum','serum.jpg'),('ساشه جوشان','Effervescent Sachet','sachet.jpg'),('ساپونین رادیانس','Saponine Radiance','hero.jpg')]
for title,en,photo in branddata:
    strip.append(con(title+' — نوار برند',[
        image('تصویر کوچک '+title,photo,24,'px',image_border_radius=dims(50,unit='%'),_element_width='auto'),
        heading(title,'span',13,400,color='var(--sn-text)',link=link('{{home}}#sec-2'),_element_width='auto'),
    ],flex_direction='row',flex_wrap_mobile='nowrap',flex_align_items='center',flex_gap={'column':'8','row':'8','unit':'px','isLinked':True},width=size(25,'%'),width_mobile=size(145),css_classes='sn-strip-item'))
brandstrip=con('نوار برند پایین صفحه — قابل حذف',strip,flex_direction='row',flex_wrap='nowrap',flex_gap={'column':'20','row':'20','unit':'px','isLinked':True},width=size(720),width_mobile=size(94,'%'),padding=dims(12,20),border_radius=dims(100),background_background='classic',background_color='#FFFFFFF2',border_border='solid',border_width=dims(1),border_color='var(--sn-border)',position='fixed',_offset_orientation_h='start',_offset_x=size(0),_offset_orientation_v='end',_offset_y_end=size(24),z_index=90,css_classes='sn-brand-strip')
rail=widget('saponine-section-rail','راهنمای کناری بخش‌ها',items=[{'_id':uid(),'label':t,'anchor':'sec-'+str(i)} for i,t in enumerate(['SLIDER','Features','brands','about us','Products','Pharmacies','CONTACT'])],placement='fixed',position='left',rail_label='SLIDER',hide_mobile='yes')
header=[headerbar,brandstrip,rail]

slides=[('SAPONINE','BALANCE','PLANT BASED WELLNESS','Your Daily Dose of Wellness','hero.jpg','cover'),('BOTANICAL','SERUM','SOOTHE · HYDRATE · RENEW','Science Inspired by Nature','serum.jpg','split'),('SAPONINE','SACHET','EFFERVESCENT FORMULA','Cleanse · Balance · Renew','sachet.jpg','split')]
hero=con('اسلایدر اصلی',[
    widget('saponine-hero-slider','اسلایدها، تصاویر و موشن هدر',slides=[{'_id':uid(),'title':a,'highlight':b,'eyebrow':c,'caption':d,'image':media(e),'layout':f,'text_direction':'ltr','background_color':'#eadcf0'} for a,b,c,d,e,f in slides],autoplay='yes',interval=6000,transition='zoom',duration=1200,pause_hover='yes',show_dots='yes',show_wave='yes',hero_height=size(100,'svh'),min_height=size(640),min_height_mobile=size(720),cover_position_mobile='25% bottom',wave_color='var(--sn-bg)'),
    widget('saponine-marquee','نشان گردان — متن و سرعت',mode='circle',items=[{'_id':uid(),'text':'Scientific Trust · Premium Quality · Scientific Trust ·'}],center_text='SAPONINE\nPHARMA',duration=24,animate='yes',circle_size=size(124),_css_classes='sn-wave-seal',_position='absolute',_offset_orientation_h='end',_offset_x_end=size(7,'%'),_offset_orientation_v='end',_offset_y_end=size(7),_z_index=13,_element_width='auto'),
],_element_id='sec-0',html_tag='section',css_classes='sn-hero-section',padding=dims(0),width=size(100,'%'))

def feature(title,desc,ic,delay=0):
    return con(title,[
        con('دایره و آیکون '+title,[icon('آیکون '+title,ic)],width=size(80),width_tablet=size(80),width_mobile=size(64),min_height=size(80),min_height_mobile=size(64),flex_align_items='center',flex_justify_content='center',background_background='classic',background_color='#ffffff',border_border='solid',border_color='var(--sn-border)',border_width=dims(1),border_radius=dims(50,unit='%'),sn_motion_effect='rotate',sn_motion_trigger='hover',sn_motion_rotation=12,sn_motion_duration=1400,css_classes='sn-feature-icon'),
        con('متن '+title,[heading(title,'h3',20,500),text(desc,14,color='var(--sn-muted)',_margin=dims(8,0,0))],width=size(72,'%'),width_tablet=size(72,'%'),width_mobile=size(72,'%'),css_classes='sn-feature-copy'),
    ],flex_direction='row',flex_wrap_tablet='nowrap',flex_wrap_mobile='nowrap',flex_align_items='center',flex_gap={'column':'20','row':'20','unit':'px','isLinked':True},flex_gap_mobile={'column':'16','row':'16','unit':'px','isLinked':True},width_tablet=size(48,'%'),width_mobile=size(100,'%'),css_classes='sn-feature-item',**reveal(delay))

# The feature bottle is built from editable native containers, logo and text.
bottlebody=con('بدنه بطری — رنگ، ابعاد و شکل',[
    image('لوگوی روی بطری','logo.png',125,'px'),
    heading('PHARMACEUTICAL COMPANY','span',7,500,'center','var(--sn-primary)',typography_font_family='Outfit'),
    con('نوار رنگی بطری',[],min_height=size(26),width=size(100,'%'),background_background='classic',background_color='var(--sn-secondary)',margin=dims(28,0,0)),
],width=size(170),width_tablet=size(170),width_mobile=size(170),min_height=size(255),flex_justify_content='center',flex_align_items='center',background_background='gradient',background_color='#ffffff',background_color_b='#eee6f3',background_gradient_angle=size(100,'deg'),border_border='solid',border_width=dims(1),border_color='var(--sn-border)',border_radius=dims(34,34,24,24),padding=dims(40,0,12),css_classes='sn-bottle-body')
bottleneck=con('گردن بطری',[],width=size(102),width_tablet=size(102),width_mobile=size(102),min_height=size(36),background_background='classic',background_color='#ffffff',border_border='solid',border_width=dims(1),border_color='var(--sn-border)',margin=dims(0,0,-8),css_classes='sn-bottle-neck')
bottlecap=con('در بطری — حرکت باز شدن',[],width=size(118),width_tablet=size(118),width_mobile=size(118),min_height=size(31),background_background='classic',background_color='var(--sn-primary)',border_radius=dims(7),margin=dims(0,0,-6),z_index=2,sn_motion_effect='float',sn_motion_trigger='hover',sn_motion_duration=2200,sn_motion_distance=65,sn_motion_mobile='',css_classes='sn-bottle-cap')
bottlering=con('حلقه تزئینی بطری — رنگ و ابعاد قابل ویرایش',[],width=size(90,'%'),width_tablet=size(90,'%'),width_mobile=size(90,'%'),min_height=size(380),min_height_mobile=size(320),border_border='solid',border_width=dims(1),border_color='var(--sn-border)',border_radius=dims(50,unit='%'),position='absolute',_offset_orientation_h='start',_offset_x=size(5,'%'),_offset_orientation_v='start',_offset_y=size(35),z_index=-1,css_classes='sn-bottle-ring')
bottle=con('بطری متحرک — اجزای باز و قابل ویرایش',[bottlering,bottlecap,bottleneck,bottlebody],flex_align_items='center',flex_justify_content='center',width=size(100,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),min_height=size(450),min_height_mobile=size(390),sn_motion_effect='rotate',sn_motion_rotation=5,sn_motion_duration=7000,sn_motion_trigger='viewport',css_classes='sn-bottle-scene')
features=section('ویژگی‌ها و بطری','sec-1',[
    heading('Saponine','div',180,700,'center','var(--sn-secondary)',typography_font_family='Outfit',_css_classes='sn-watermark',_position='absolute',_offset_y=size(42,'%'),_element_width='initial',_element_custom_width=size(100,'%'),_z_index=0),
    heading('رویکردی که ما را متمایز می‌کند',font=30,align='center',**reveal()),
    text('سبکِ زندگیِ هدفمند، با راهکارهایِ علمیِ ساپونین',align='center',color='var(--sn-muted)',_margin=dims(16,0,0),**reveal(120)),
    con('چیدمان سه ستون ویژگی‌ها',[
        con('ویژگی‌های سمت راست',[feature('فرمولاسیون','فرمولاسیونِ مبتنی‌بر شواهدِ علمی','dna'),feature('نگاهِ کل‌نگر','نگاه کل‌نگر و ریشه‌ای به سلامت','leaf',150)],width=size(30,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),flex_direction_tablet='row',flex_direction_mobile='column',flex_gap={'column':'56','row':'56','unit':'px','isLinked':True},flex_gap_tablet={'column':'24','row':'24','unit':'px','isLinked':True},flex_gap_mobile={'column':'24','row':'24','unit':'px','isLinked':True},css_classes='sn-feature-column'),
        con('ستون بطری',[bottle],width=size(40,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),css_classes='sn-bottle-column'),
        con('ویژگی‌های سمت چپ',[feature('کیفیت','کیفیت پریمیوم و ارزش‌آفرین','award'),feature('اعتمادِ علمی','محصولاتی با پشتوانه مطالعات بالینی','shield-alt',150)],width=size(30,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),flex_direction_tablet='row',flex_direction_mobile='column',flex_gap={'column':'56','row':'56','unit':'px','isLinked':True},flex_gap_tablet={'column':'24','row':'24','unit':'px','isLinked':True},flex_gap_mobile={'column':'24','row':'24','unit':'px','isLinked':True},css_classes='sn-feature-column'),
    ],flex_direction='row',flex_direction_tablet='column',flex_direction_mobile='column',flex_align_items='center',flex_gap={'column':'28','row':'28','unit':'px','isLinked':True},margin=dims(18,0,0),css_classes='sn-feature-layout'),
])
cards=[]
for i,(title,en,photo) in enumerate(branddata):
    cards.append(con('کارت '+title,[
        con('لوگوی برند',[image('تصویر برند '+title,'logo.png',80,'px',link_to='custom',link=link('#sec-4'))],width=size(96),width_tablet=size(96),width_mobile=size(96),min_height=size(96),border_border='solid',border_width=dims(1),border_color='var(--sn-border)',border_radius=dims(50,unit='%'),background_background='classic',background_color='#ffffff',flex_justify_content='center',flex_align_items='center',css_classes='sn-brand-logo'),
        heading(title,'h3',18,700,'center',_margin=dims(20,0,0),link=link('#sec-4')),
        text(en,14,'center','var(--sn-muted)',typography_font_family='Outfit'),
        icon('پیکان '+title,'arrow-left',size=size(20),link=link('#sec-4'),_margin=dims(20,0,0)),
    ],width=size(24,'%'),width_tablet=size(47,'%'),width_mobile=size(47,'%'),min_height=size(280),padding=dims(24),padding_mobile=dims(20,10),border_border='solid',border_width=dims(1),border_color='var(--sn-border)',border_radius=dims(24),background_background='classic',background_color='#FFFFFFCC',flex_align_items='center',css_classes='sn-brand-card',**reveal(180+i*120)))
brands=section('برندهای ما','sec-2',[
    con('حلقه تزئینی بالا — قابل ویرایش',[],width=size(620),min_height=size(620),border_border='solid',border_width=dims(90),border_color='var(--sn-secondary)',border_radius=dims(50,unit='%'),position='absolute',_offset_orientation_h='end',_offset_x_end=size(-250),_offset_orientation_v='start',_offset_y=size(-260),z_index=-1,css_classes='sn-brand-motif'),
    con('حلقه تزئینی پایین — قابل ویرایش',[],width=size(620),min_height=size(620),border_border='solid',border_width=dims(90),border_color='var(--sn-secondary)',border_radius=dims(50,unit='%'),position='absolute',_offset_orientation_h='start',_offset_x=size(-240),_offset_orientation_v='end',_offset_y_end=size(-220),z_index=-1,css_classes='sn-brand-motif'),
    heading('برنـدهای مـا',align='center',**reveal()),text('هر محصول، یک تجربه متفاوت',align='center',color='var(--sn-muted)',_margin=dims(16,0,0)),
    con('کارت‌های مستقل برند',cards,flex_direction='row',flex_wrap='wrap',flex_justify_content='space-between',flex_gap={'column':'12','row':'24','unit':'px','isLinked':False},margin=dims(56,0,0),css_classes='sn-brand-grid'),
    button('مشاهده همه محصولات','#sec-4',align='center',_margin=dims(36,0,0)),
],css_classes='sn-panel sn-brands-panel')
about=section('درباره ساپونین','sec-3',[
    con('متن درباره شرکت',[
        heading('ABOUT US','span',14,500,color='var(--sn-primary)',typography_font_family='Outfit',typography_letter_spacing=size(5)),
        heading('درباره ساپونین',_margin=dims(16,0,0)),
        text('شرکت داروسازی ساپونین با هدف توسعه‌ی راهکارها و محصولاتی نوآورانه و باکیفیت، در مسیر ارتقای سبک زندگی و بازتعریف نگاه به سلامت فعالیت می‌کند. تمرکز ما تنها بر تولید مکمل‌های غذایی و دارویی نیست؛ بلکه بر ایجاد نگاهی عمیق‌تر و علمی به سلامت است.',color='var(--sn-muted)',typography_line_height=size(2.25,'em'),_margin=dims(24,0,0)),
        con('دکمه‌های درباره ما',[button('درباره ما','#sec-3'),button('تماس با ما','#sec-6',outline=True)],flex_direction='row',flex_wrap_mobile='wrap',flex_gap={'column':'12','row':'12','unit':'px','isLinked':True},margin=dims(32,0,0),css_classes='sn-about-actions'),
    ],width=size(48,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),css_classes='sn-about-copy',**reveal()),
    con('تصویر درباره شرکت',[image('محصولات ساپونین','hero.jpg',100,'%',height=size(440),height_tablet=size(360),height_mobile=size(260),object_fit='cover',object_position='left',image_border_radius=dims(40),_css_classes='sn-about-image')],width=size(48,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),css_classes='sn-about-media',**reveal(150)),
],flex_direction='row',flex_direction_tablet='column',flex_direction_mobile='column',flex_align_items='center',flex_gap={'column':'56','row':'32','unit':'px','isLinked':False},css_classes='sn-panel sn-about-layout')
products=[
    ('ساپونین بالانس','Saponine Balance','bottle.jpg','مکمل گیاهی ساپونین بالانس با ترکیبات طبیعی، برای حمایت از تعادل روزانه بدن و تقویت سیستم ایمنی طراحی شده است.','تقویت سیستم ایمنی\nخاصیت آنتی‌اکسیدانی\nترکیبات کاملاً گیاهی','سه ماه'),
    ('سرم بوتانیکال','Botanical Serum','serum.jpg','سرم بوتانیکال ساپونین با عصاره‌های گیاهی، به آبرسانی عمقی، تسکین و بازسازی پوست کمک می‌کند.','آبرسانی عمقی پوست\nتسکین و کاهش التهاب\nبازسازی و شادابی پوست','۶۰ تا ۹۰ روز'),
    ('ساشه جوشان','Effervescent Sachet','sachet.jpg','ساشه جوشان ساپونین فرمولی سریع‌الجذب برای حمایت روزانه از سلامت و پاکسازی طبیعی بدن است.','جذب سریع و آسان\nحمایت آنتی‌اکسیدانی\nسلامت روزانه','۳ تا ۶ ماه'),
]
productsection=section('نمایش متحرک محصولات','sec-4',[
    widget('saponine-product-showcase','محصولات — عکس، محتوا، چیدمان و موشن',products=[{'_id':uid(),'title':a,'en_title':b,'image':media(c),'image_alt':a,'description':d,'detail_description':d,'features':e,'usage':f,'cta_label':'','cta_link':link('')} for a,b,c,d,e,f in products],details_label='جزییات محصول',view_label='مشاهده محصول',usage_label='حداقل مدت زمان مصرف',modal_kicker='SAPONINE PRODUCT',show_tabs='yes',show_arrows='yes',show_ring='yes',enable_modal='yes',float_enabled='yes',tilt_enabled='yes',ring_spin='yes',float_amplitude=13,float_duration=6.5,tilt_amount=11,ring_duration=34,transition_type='rotate',transition_duration=720,modal_animation='flip',modal_duration=850),
],background_background='gradient',background_color='#d9c7ec',background_color_b='#f1dce7',background_gradient_angle=size(100,'deg'))
pharmacy=section('داروخانه‌ها','sec-5',[
    con('کارت داروخانه‌ها',[
        heading('داروخـانه‌ها',align='center',color='#ffffff'),
        text('دسترسی سریع و مطمئن به محصولات ساپونین',18,'center','#ffffff',_margin=dims(16,0,0)),
        text('داروخانه‌های معرفی‌شده، مراکز معتبر و مورد تأیید ساپونین هستند که محصولات را به‌صورت قانونی و با رعایت شرایط نگهداری عرضه می‌کنند.',align='center',color='#ffffff',_margin=dims(16,0,0),_element_width='initial',_element_custom_width=size(670),_element_custom_width_tablet=size(100,'%'),_element_custom_width_mobile=size(100,'%'),_css_classes='sn-pharmacy-text'),
        button('مشاهده همه داروخانه‌ها','#sec-6',light=True,align='center',_margin=dims(32,0,0)),
    ],border_radius=dims(40),padding=dims(80),padding_tablet=dims(64,40),padding_mobile=dims(48,24),background_background='gradient',background_color='#e7b7d2',background_color_b='var(--sn-primary)',background_gradient_angle=size(120,'deg'),flex_align_items='center',css_classes='sn-pharmacy-card',**reveal()),
])
home=[hero,features,brands,about,productsection,pharmacy]

footcols=[con('لوگو و معرفی پابرگ',[
    con('زمینه لوگوی پابرگ',[image('لوگوی پابرگ','logo.png',128,'px')],width=size(152),width_tablet=size(152),width_mobile=size(152),padding=dims(12),border_radius=dims(16),background_background='classic',background_color='#ffffff',css_classes='sn-footer-logo-plate'),
    text('شرکت داروسازی ساپونین؛ سلامت هدفمند با پشتوانه علمی.',14,color='#D7D2DD',_margin=dims(16,0,0))
],width=size(25,'%'),width_tablet=size(100,'%'),width_mobile=size(100,'%'),css_classes='sn-footer-column sn-footer-intro')]
for title,items in [
    ('دسته‌بندی‌ها',[('مکمل‌ها','sec-4'),('مراقبت پوست','sec-4'),('سلامت روزانه','sec-4')]),
    ('برندها',[(a,'sec-4') for a,_,_ in branddata]),
    ('دسترسی سریع',[('درباره ما','sec-3'),('تماس با ما','sec-6'),('مجله ساپونین','sec-3'),('داروخانه‌ها','sec-5')])
]:
    footcols.append(con(title,[heading(title,'h4',16,700,color='#ffffff')]+[heading(t,'div',14,400,color='#D7D2DD',link=link('{{home}}#'+a),_margin=dims(8,0,0)) for t,a in items],width=size(23,'%'),width_tablet=size(31,'%'),width_mobile=size(44,'%'),css_classes='sn-footer-column'))
footer=[con('پابرگ — همه ستون‌ها قابل جابه‌جایی',[
    con('ستون‌های پابرگ',footcols,content_width='boxed',boxed_width=size(1280),flex_direction='row',flex_wrap='wrap',flex_gap={'column':'24','row':'32','unit':'px','isLinked':False},padding=dims(64,24),css_classes='sn-footer-columns'),
    text('© ۱۴۰۵ شرکت داروسازی ساپونین. تمامی حقوق محفوظ است.',12,'center','#AAA3AF',_padding=dims(20,20,8),_border_border='solid',_border_width=dims(1,0,0),_border_color='#ffffff19'),
    heading('طراحی،توسعه و پشتیبانی با هلدینگ کلاسیکا','div',14,400,'center','#AAA3AF',name='امضای هلدینگ کلاسیکا — متن و لینک قابل ویرایش',link=link('https://alimoradicoach.ir/'),_padding=dims(4,20,88),_css_classes='sn-classika-credit'),
],_element_id='sec-6',html_tag='div',background_background='classic',background_color='#27222E',min_height=size(100,'vh'),min_height_mobile=size(0),flex_justify_content='center',css_classes='sn-footer')]

# Extend the original four-item header after the original nodes have been built.
# Their Elementor IDs are also used by saved layouts and translated copies.
showcase = productsection['elements'][0]
for item, product in zip(strip, showcase['settings']['products']):
    anchor = 'sp-item-' + showcase['id'] + '-' + product['_id']
    item['elements'][1]['settings']['link'] = link('{{home}}#' + anchor)
cards[3]['settings']['_element_id'] = 'sp-brand-radiance'
strip[3]['elements'][1]['settings']['link'] = link('{{home}}#sp-brand-radiance')
all_products = con('همه محصولات — نوار برند', [
    icon('فهرست محصولات','th-large',size=size(14),_element_width='auto'),
    heading('همه محصولات','span',15,400,link=link('{{home}}#sec-4'),_element_width='auto'),
],flex_direction='row',flex_align_items='center',css_classes='sn-strip-item')
strip.append(all_products)
brandstrip['settings'].update(width=size(654), padding=dims(8,14), _offset_y_end=size(29),
                              background_color='#FFFFFFAA', border_color='#FFFFFFBF')
rail['settings'].update(edge_offset=size(18),line_height=25,active_height=62,line_width=2,active_label='yes')

for name,content,kind in [('home',home,'page'),('header',header,'section'),('footer',footer,'section')]:
    data={'version':'0.4','title':'Saponine — '+name,'type':kind,'content':content,'page_settings':{'hide_title':'yes'},'saponine_schema':2}
    (OUT/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# An optional insertable block for existing footers, preserving their saved design.
credit_template={'version':'0.4','title':'Classika — Footer credit','type':'section','content':[con('امضای کلاسیکا برای افزودن به پابرگ موجود',[footer[0]['elements'][-1]])],'page_settings':{}}
(ROOT/'footer-credit.json').write_text(json.dumps(credit_template,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Built three editable Elementor documents and the optional footer-credit block.')
